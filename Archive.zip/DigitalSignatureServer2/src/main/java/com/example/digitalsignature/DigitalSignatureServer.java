package com.example.digitalsignature;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class DigitalSignatureServer {
    private static String receivedPublicKey; // Saugo gautą viešąjį raktą
    private static String receivedMessage; // Saugo gautą žinutę
    private static String receivedDigitalSignature; // Saugo gautą skaitmeninį parašą

    public static void main(String[] args) {
        try {
            // Sukuria serverio socket'ą, kuris klausosi prievado 6000
            ServerSocket serverSocket = new ServerSocket(6000);
            System.out.println("Server is listening on port 6000...");

            while (true) {
                System.out.println("Waiting for a connection...");
                // Priima naują jungtį iš kliento
                Socket socket = serverSocket.accept();
                System.out.println("Connection accepted from " + socket.getInetAddress());

                try (ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream())) {
                    // Nuskaito viešąjį raktą, žinutę ir skaitmeninį parašą iš kliento
                    receivedPublicKey = (String) inputStream.readObject();
                    receivedMessage = (String) inputStream.readObject();
                    receivedDigitalSignature = (String) inputStream.readObject();

                    System.out.println("Received Public Key: " + receivedPublicKey);
                    System.out.println("Received Message: " + receivedMessage);
                    System.out.println("Received Digital Signature: " + receivedDigitalSignature);
                } catch (Exception e) {
                    System.out.println("Error during data reception: " + e.getMessage());
                    e.printStackTrace();
                }

                // Leidžia vartotojui manipuliuoti skaitmeniniu parašu, jei reikia
                Scanner scanner = new Scanner(System.in);
                System.out.println("Do you want to manipulate the digital signature? (yes/no):");
                String manipulate = scanner.nextLine();
                String manipulatedSignature = receivedDigitalSignature;
                if ("yes".equalsIgnoreCase(manipulate)) {
                    // Pakeičia pirmąjį 'A' simbolį į 'B' skaitmeniniame paraše (tik pavyzdys)
                    manipulatedSignature = receivedDigitalSignature.replace("A", "B");
                    System.out.println("Manipulated Digital Signature: " + manipulatedSignature);
                }

                // Persiunčia duomenis verifikatoriui
                try (Socket verifierSocket = new Socket("localhost", 6001);
                     ObjectOutputStream outputStream = new ObjectOutputStream(verifierSocket.getOutputStream())) {
                    outputStream.writeObject(receivedPublicKey);
                    outputStream.writeObject(receivedMessage);
                    outputStream.writeObject(manipulatedSignature);
                    System.out.println("Data sent to verifier.");
                } catch (Exception e) {
                    System.out.println("Error sending data to verifier: " + e.getMessage());
                    e.printStackTrace();
                }

                // Uždaro socket'ą
                socket.close();
                System.out.println("Connection closed.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
