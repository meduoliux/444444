package com.example.digitalsignature;

import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class DigitalSignatureVerifier {
    public static void main(String[] args) {
        try {
            System.out.println("Verifier is waiting for data...");
            // Sukuriamas serverio socket'as, kuris klausosi prievado 6001
            ServerSocket serverSocket = new ServerSocket(6001);
            // Priimama jungtis iš serverio
            Socket socket = serverSocket.accept();
            System.out.println("Verifier received a connection.");

            try (ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream())) {
                System.out.println("Reading data from server...");
                // Nuskaitomi duomenys iš serverio: viešasis raktas, žinutė ir skaitmeninis parašas
                String encodedPublicKey = (String) inputStream.readObject();
                String message = (String) inputStream.readObject();
                String encodedSignature = (String) inputStream.readObject();

                System.out.println("Received Public Key: " + encodedPublicKey);
                System.out.println("Received Message: " + message);
                System.out.println("Received Digital Signature: " + encodedSignature);

                // Dekoduojamas viešasis raktas iš Base64 formato
                byte[] publicKeyBytes = Base64.getDecoder().decode(encodedPublicKey);
                X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicKeyBytes);
                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                PublicKey publicKey = keyFactory.generatePublic(keySpec);

                System.out.println("Public key decoded successfully.");

                // Dekoduojamas skaitmeninis parašas iš Base64 formato
                byte[] signatureBytes = Base64.getDecoder().decode(encodedSignature);

                System.out.println("Digital signature decoded successfully.");

                // Tikrinamas skaitmeninis parašas naudojant viešąjį raktą
                Signature signature = Signature.getInstance("SHA256withRSA");
                signature.initVerify(publicKey);
                signature.update(message.getBytes());

                boolean isVerified = signature.verify(signatureBytes);
                if (isVerified) {
                    System.out.println("The digital signature is valid.");
                } else {
                    System.out.println("The digital signature is invalid.");
                }
            } catch (Exception e) {
                System.out.println("Error during data processing: " + e.getMessage());
                e.printStackTrace();
            }

            // Uždaromi socket'ai
            socket.close();
            serverSocket.close();
        } catch (Exception e) {
            System.out.println("Error during connection: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
