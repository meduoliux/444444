package com.example.digitalsignature;

import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Base64;
import java.util.Scanner;

public class DigitalSignatureSender {
    public static void main(String[] args) {
        try {
            // 1 žingsnis: Sugeneruoti raktų porą (RSA)
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(2048); // Inicializuoja raktų generatorių su 2048 bitų raktų dydžiu
            KeyPair keyPair = keyGen.generateKeyPair(); // Sugeneruoja raktų porą
            PrivateKey privateKey = keyPair.getPrivate(); // Gauk privatų raktą iš raktų poros
            PublicKey publicKey = keyPair.getPublic(); // Gauk viešąjį raktą iš raktų poros

            // 2 žingsnis: Įvesti pranešimą
            Scanner scanner = new Scanner(System.in); // Sukuria skenerio objektą skaityti įvestį iš komandinės eilutės
            System.out.println("Enter a message to be signed:"); // Prašo vartotojo įvesti pranešimą
            String message = scanner.nextLine(); // Nuskaito vartotojo įvestą pranešimą

            // 3 žingsnis: Sukurti skaitmeninį parašą
            Signature sign = Signature.getInstance("SHA256withRSA"); // Sukuria Signature objektą su SHA256 ir RSA algoritmu
            sign.initSign(privateKey); // Inicializuoja Signature objektą su privačiu raktu pasirašymui
            sign.update(message.getBytes()); // Prideda pranešimą pasirašymui
            byte[] digitalSignature = sign.sign(); // Pasirašo pranešimą ir sukuria skaitmeninį parašą

            // Užkoduoti skaitmeninį parašą ir viešąjį raktą
            String encodedSignature = Base64.getEncoder().encodeToString(digitalSignature); // Užkoduoja skaitmeninį parašą į Base64 formatą
            String encodedPublicKey = Base64.getEncoder().encodeToString(publicKey.getEncoded()); // Užkoduoja viešąjį raktą į Base64 formatą

            // 4 žingsnis: Siųsti viešąjį raktą, pranešimą ir skaitmeninį parašą serveriui
            Socket socket = new Socket("localhost", 6000); // Sukuria socket'ą jungimuisi prie serverio prievade 6000
            ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream()); // Sukuria ObjectOutputStream duomenų siuntimui per socket'ą
            outputStream.writeObject(encodedPublicKey); // Išsiunčia užkoduotą viešąjį raktą
            outputStream.writeObject(message); // Išsiunčia pranešimą
            outputStream.writeObject(encodedSignature); // Išsiunčia užkoduotą skaitmeninį parašą

            // Uždaro srautą ir socket'ą
            outputStream.close(); // Uždaro OutputStream
            socket.close(); // Uždaro socket'ą

            System.out.println("Data sent to the server successfully."); // Praneša, kad duomenys sėkmingai išsiųsti serveriui
        } catch (Exception e) {
            e.printStackTrace(); // Išspausdina klaidos pranešimą, jei įvyksta klaida
        }
    }
}
